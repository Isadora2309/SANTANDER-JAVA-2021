package com.dioJavaProject3.service;
@Repository
public interface JornadaRepository extends JpaRepository <JornadaTrabalho, Long>{

}